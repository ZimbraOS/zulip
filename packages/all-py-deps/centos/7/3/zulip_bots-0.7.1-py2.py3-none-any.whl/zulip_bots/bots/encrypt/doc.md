About EncryptBot:
EncryptBot Allows for quick ROT13 encryption in the middle of a chat.

What It Does:
The bot encrypts any message sent to it on any stream it is subscribed to with ROT13.

How It Works:
The bot will Use ROT13(A -> N, B -> O... and vice-versa) in a python
implementation to provide quick and easy encryption.

How to Use:

-Send the message you want to encrypt, add @encrypt to the beginning.
-The Encrypted message will be sent back to the stream the original
message was posted in to the topic <sender-email>'s encrypted text.
-Messages can be decrypted by sending them to EncryptBot in the same way.
