from __future__ import absolute_import

__all__ = ('bitand', 'bitor')


def bitand(a, b):
    return a.bitand(b)


def bitor(a, b):
    return a.bitor(b)
