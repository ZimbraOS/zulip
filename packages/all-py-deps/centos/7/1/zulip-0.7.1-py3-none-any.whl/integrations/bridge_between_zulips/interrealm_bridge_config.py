config = {
    "bot_1": {
        "email": "tunnel-bot@realm1.zulipchat.com",
        "api_key": "key1",
        "site": "https://realm1.zulipchat.com",
        "stream": "bridges",
        "subject": "<- realm2"},
    "bot_2": {
        "email": "tunnel-bot@realm2.zulipchat.com",
        "api_key": "key2",
        "site": "https://realm2.zulipchat.com",
        "stream": "bridges",
        "subject": "<- realm1"}
}
