"""OpenAPI core exceptions module"""


class OpenAPIError(Exception):
    pass
