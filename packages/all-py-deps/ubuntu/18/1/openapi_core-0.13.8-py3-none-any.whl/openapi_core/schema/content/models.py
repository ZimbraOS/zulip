"""OpenAPI core content models module"""


class Content(dict):
    pass
