"""OpenAPI core security requirements models module"""


class SecurityRequirement(dict):
    """Represents an OpenAPI Security Requirement."""
    pass
