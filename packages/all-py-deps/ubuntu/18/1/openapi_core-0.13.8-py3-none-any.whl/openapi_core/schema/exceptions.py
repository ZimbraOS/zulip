"""OpenAPI core schema exceptions module"""
from openapi_core.exceptions import OpenAPIError


class OpenAPIMappingError(OpenAPIError):
    pass
