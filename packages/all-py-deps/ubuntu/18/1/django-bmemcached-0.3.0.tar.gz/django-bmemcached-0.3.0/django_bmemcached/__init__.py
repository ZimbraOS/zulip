from .memcached import BMemcached
assert BMemcached
