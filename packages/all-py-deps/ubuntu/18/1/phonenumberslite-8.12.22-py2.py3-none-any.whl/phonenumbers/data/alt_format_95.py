"""Auto-generated file, do not edit by hand. 95 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_95 = [NumberFormat(pattern='(\\d)(\\d{4})(\\d{5})', format='\\1 \\2 \\3', leading_digits_pattern=['92'])]
