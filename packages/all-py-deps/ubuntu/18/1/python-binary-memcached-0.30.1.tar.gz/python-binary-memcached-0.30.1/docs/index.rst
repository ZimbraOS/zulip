.. Python Binary Memcached (bmemached) documentation master file, created by
   sphinx-quickstart on Mon Apr 15 12:02:27 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python Binary Memcached (bmemached)'s documentation!
===============================================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   bmemcached
   modules



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

