config = {
    "zulip": {
        "email": "zulip-bot@email.com",
        "api_key": "put api key here",
        "site": "https://chat.zulip.org",
        "stream": "test here",
        "topic": "<- slack-bridge",
    },
    "slack": {
        "username": "slack username",
        "token": "slack token",
        "channel": "C5Z5N7R8A -- must be channel id",
    }
}
