from django_statsd import patches
from django_statsd import clients

from django_statsd.plugins import NoseStatsd
