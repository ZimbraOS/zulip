from statsd.client import StatsClient
