# This is just a place holder, the toolbar works well enough for now.
from django_statsd.clients.toolbar import StatsClient
