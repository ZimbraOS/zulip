============================
Django Statsd |Build Status|
============================

Documentation is on `Read the Docs <https://django-statsd.readthedocs.org/>`_.

-------
License
-------

BSD and MPL

Portions of this are from commonware:

https://github.com/jsocol/commonware/blob/master/LICENSE

.. |Build Status| image:: https://travis-ci.org/django-statsd/django-statsd.svg?branch=master
   :target: https://travis-ci.org/django-statsd/django-statsd


