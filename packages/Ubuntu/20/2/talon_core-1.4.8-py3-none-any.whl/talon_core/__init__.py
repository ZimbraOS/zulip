from __future__ import absolute_import
from talon_core.quotations import register_xpath_extensions


def init():
    register_xpath_extensions()
