from talon_core.quotations import *
